#!/bin/bash

cd
curl -L "https://github.com/danielj195/CSCE-222/archive/master.zip" -o "A2.zip" # downloads the .zip file from github
unzip A2.zip # unzips the downloaded file to make a directory